#!/usr/bin/env python
"""Audit local eAP/GarlTTC data and repository state for an object-centric LHR patch.

The audit is read-only. It does not copy raw events, RGB images, masks, or
parquet tables. It writes compact schema/statistics reports plus a snapshot of
the small source/config files that the future patch must modify.
"""

from __future__ import annotations

import argparse
import ast
import hashlib
import json
import math
import os
import shutil
import subprocess
import sys
import tarfile
import traceback
import zipfile
from collections import Counter
from pathlib import Path
from typing import Any, Iterable

import h5py
import numpy as np
import pandas as pd

JOIN_KEYS = [
    "sequence_id",
    "sample_token",
    "track_id",
    "public_track_id",
    "timestamp_us",
]

NESTED_FIELDS = [
    "frame_timestamps_us",
    "event_windows_us",
    "boxes_xyxy",
    "frame_ttc",
    "box3d_Fcam",
    "rgb_shard_paths",
    "rgb_member_paths",
]

SOURCE_SNAPSHOT_PATHS = [
    "AGENTS.md",
    "pyproject.toml",
    "scripts/screen_highres_real_garl.py",
    "scripts/train_e_jepa_tubelet_lhr.py",
    "scripts/run_e_jepa_garl_final.py",
    "src/e_jepa_ttc/data/eap.py",
    "src/e_jepa_ttc/data/eap_representation.py",
    "src/e_jepa_ttc/data/garlttc_eap.py",
    "src/e_jepa_ttc/data/garlttc_lhr_cache.py",
    "src/e_jepa_ttc/data/garlttc_sampling.py",
    "src/e_jepa_ttc/models/highres_factorized.py",
    "src/e_jepa_ttc/evaluation/garl_ttc_protocol.py",
    "configs/model/e_jepa_tubelet_lhr_dense_level_dynamics_screen_v1.yaml",
    "configs/train/garl_highres_stable_scratch_screen_v3.yaml",
    "configs/train/garl_highres_stable_transfer_screen_v3.yaml",
    "configs/experiment/e_jepa_garl_event_dense_level_dynamics_stable_scratch_screen_v3.yaml",
    "configs/experiment/e_jepa_garl_event_dense_level_dynamics_stable_transfer_screen_v3.yaml",
    "tests/unit/test_highres_factorized.py",
    "tests/unit/test_garlttc_eap.py",
    "tests/integration/test_tubelet_lhr_stable_screen.py",
]


def run_command(args: list[str], cwd: Path) -> dict[str, Any]:
    result = subprocess.run(
        args,
        cwd=cwd,
        capture_output=True,
        text=True,
        check=False,
    )
    return {
        "args": args,
        "returncode": result.returncode,
        "stdout": result.stdout,
        "stderr": result.stderr,
    }


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def json_safe(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, bool)):
        return value
    if isinstance(value, float):
        return value if math.isfinite(value) else str(value)
    if isinstance(value, np.generic):
        return json_safe(value.item())
    if isinstance(value, np.ndarray):
        return [json_safe(item) for item in value.tolist()]
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, dict):
        return {str(key): json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [json_safe(item) for item in value]
    as_py = getattr(value, "as_py", None)
    if callable(as_py):
        return json_safe(as_py())
    return str(value)


def to_python(value: Any) -> Any:
    as_py = getattr(value, "as_py", None)
    if callable(as_py):
        value = as_py()
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, str):
        stripped = value.strip()
        if not stripped:
            return value
        if stripped[0] in "[{(":
            for parser in (ast.literal_eval, json.loads):
                try:
                    return parser(stripped)
                except Exception:
                    continue
    return value


def nested_length(value: Any) -> int | None:
    value = to_python(value)
    if value is None:
        return None
    if isinstance(value, float) and math.isnan(value):
        return None
    if isinstance(value, (list, tuple)):
        return len(value)
    return None


def canonical_nested(value: Any) -> str:
    return json.dumps(
        json_safe(to_python(value)),
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
    )


def locate_parquet(root: Path, relative_candidates: list[str], suffix: str) -> Path:
    for relative in relative_candidates:
        candidate = root / relative
        if candidate.is_file():
            return candidate.resolve()
    matches = sorted(root.rglob(suffix))
    if not matches:
        raise FileNotFoundError(
            f"No se encontró {suffix!r} bajo {root}. "
            f"Se probaron: {relative_candidates}"
        )
    if len(matches) > 1:
        preferred = [
            item
            for item in matches
            if "test" not in item.as_posix().lower()
        ]
        if len(preferred) == 1:
            return preferred[0].resolve()
        raise RuntimeError(
            f"Hay varios candidatos para {suffix}: "
            + ", ".join(str(item) for item in matches[:20])
        )
    return matches[0].resolve()


def dataframe_schema(frame: pd.DataFrame) -> dict[str, Any]:
    return {
        "rows": int(len(frame)),
        "columns": list(frame.columns),
        "dtypes": {column: str(dtype) for column, dtype in frame.dtypes.items()},
        "null_counts": {
            column: int(frame[column].isna().sum())
            for column in frame.columns
        },
    }


def alignment_report(frame: pd.DataFrame) -> dict[str, Any]:
    available = [field for field in NESTED_FIELDS if field in frame.columns]
    lengths: dict[str, pd.Series] = {
        field: frame[field].map(nested_length)
        for field in available
    }
    result: dict[str, Any] = {
        "available_fields": available,
        "length_distributions": {},
        "pairwise_alignment": {},
    }
    for field, series in lengths.items():
        counts = Counter("null" if value is None or pd.isna(value) else str(int(value)) for value in series)
        result["length_distributions"][field] = dict(counts.most_common(20))

    reference = lengths.get("frame_timestamps_us")
    if reference is not None:
        for field, series in lengths.items():
            if field == "frame_timestamps_us":
                continue
            valid = reference.notna() & series.notna()
            if not bool(valid.any()):
                result["pairwise_alignment"][field] = {
                    "comparable_rows": 0,
                    "matching_rows": 0,
                    "mismatching_rows": 0,
                }
                continue
            matching = reference[valid].astype(int) == series[valid].astype(int)
            result["pairwise_alignment"][field] = {
                "comparable_rows": int(valid.sum()),
                "matching_rows": int(matching.sum()),
                "mismatching_rows": int((~matching).sum()),
            }
    return result


def parse_boxes(value: Any) -> list[tuple[float, float, float, float]]:
    value = to_python(value)
    if not isinstance(value, (list, tuple)):
        return []
    if len(value) == 4 and all(np.isscalar(item) for item in value):
        value = [value]
    boxes: list[tuple[float, float, float, float]] = []
    for item in value:
        item = to_python(item)
        if not isinstance(item, (list, tuple)) or len(item) != 4:
            continue
        try:
            box = tuple(float(coord) for coord in item)
        except Exception:
            continue
        if all(math.isfinite(coord) for coord in box):
            boxes.append(box)
    return boxes


def parse_float_list(value: Any) -> list[float]:
    value = to_python(value)
    if not isinstance(value, (list, tuple)):
        return []
    result: list[float] = []
    for item in value:
        try:
            number = float(item)
        except Exception:
            continue
        if math.isfinite(number):
            result.append(number)
    return result


def parse_windows(value: Any) -> list[tuple[int, int]]:
    value = to_python(value)
    if not isinstance(value, (list, tuple)):
        return []
    windows: list[tuple[int, int]] = []
    for item in value:
        item = to_python(item)
        if not isinstance(item, (list, tuple)) or len(item) != 2:
            continue
        try:
            start, end = int(item[0]), int(item[1])
        except Exception:
            continue
        windows.append((start, end))
    return windows


def bbox_and_geometry_report(
    frame: pd.DataFrame,
    *,
    row_limit: int,
    target_delta_s: float,
) -> dict[str, Any]:
    sample = frame.head(min(row_limit, len(frame))).copy()
    widths: list[float] = []
    heights: list[float] = []
    square_edges: list[float] = []
    invalid_boxes = 0
    total_boxes = 0
    ratio_rows = 0
    bbox_ratio_abs_errors: list[float] = []
    bbox_log_ratio_abs_errors: list[float] = []
    nonpositive_target_ratios = 0
    fcam_shapes: Counter[str] = Counter()
    positive_depth_rows = 0
    invalid_depth_rows = 0

    for _, row in sample.iterrows():
        boxes = parse_boxes(row.get("boxes_xyxy"))
        for x0, y0, x1, y1 in boxes:
            total_boxes += 1
            width = x1 - x0
            height = y1 - y0
            if width <= 0 or height <= 0:
                invalid_boxes += 1
                continue
            widths.append(width)
            heights.append(height)
            square_edges.append(max(width, height))

        ttcs = parse_float_list(row.get("frame_ttc"))
        if len(boxes) >= 2 and len(ttcs) >= 2:
            timestamps = parse_float_list(row.get("frame_timestamps_us"))
            first = 0
            second = len(boxes) - 1
            if len(timestamps) == len(boxes):
                anchor = float(row.get("timestamp_us", timestamps[-1]))
                second = int(np.argmin(np.abs(np.asarray(timestamps) - anchor)))
                desired = timestamps[second] - target_delta_s * 1e6
                first = int(np.argmin(np.abs(np.asarray(timestamps) - desired)))
                if first == second and second > 0:
                    first = second - 1
            if first < len(boxes) and second < len(boxes) and second < len(ttcs):
                h1 = boxes[first][3] - boxes[first][1]
                h2 = boxes[second][3] - boxes[second][1]
                target_ttc = ttcs[second]
                dt = target_delta_s
                if len(timestamps) == len(boxes):
                    dt = abs(timestamps[second] - timestamps[first]) / 1e6
                if h1 > 0 and h2 > 0 and target_ttc != 0 and dt > 0:
                    target_ratio = 1.0 - dt / target_ttc
                    observed_ratio = h1 / h2
                    ratio_rows += 1
                    bbox_ratio_abs_errors.append(abs(observed_ratio - target_ratio))
                    if target_ratio > 0 and observed_ratio > 0:
                        bbox_log_ratio_abs_errors.append(
                            abs(math.log(observed_ratio) - math.log(target_ratio))
                        )
                    else:
                        nonpositive_target_ratios += 1

        fcam = to_python(row.get("box3d_Fcam"))
        if isinstance(fcam, (list, tuple)):
            fcam_shapes[str(np.asarray(fcam, dtype=object).shape)] += 1
            try:
                array = np.asarray(fcam, dtype=np.float64)
                if array.ndim >= 3 and array.shape[-1] >= 3:
                    depths = array[..., 2]
                    if np.isfinite(depths).all() and float(depths.min()) > 0:
                        positive_depth_rows += 1
                    else:
                        invalid_depth_rows += 1
            except Exception:
                invalid_depth_rows += 1

    def stats(values: list[float]) -> dict[str, Any]:
        if not values:
            return {"count": 0}
        array = np.asarray(values, dtype=np.float64)
        return {
            "count": int(array.size),
            "min": float(array.min()),
            "p01": float(np.quantile(array, 0.01)),
            "p10": float(np.quantile(array, 0.10)),
            "median": float(np.median(array)),
            "p90": float(np.quantile(array, 0.90)),
            "p99": float(np.quantile(array, 0.99)),
            "max": float(array.max()),
            "mean": float(array.mean()),
        }

    return {
        "audited_rows": int(len(sample)),
        "total_boxes": total_boxes,
        "invalid_boxes": invalid_boxes,
        "box_width_px": stats(widths),
        "box_height_px": stats(heights),
        "square_crop_edge_px": stats(square_edges),
        "bbox_height_ratio_vs_ttc": {
            "comparable_rows": ratio_rows,
            "absolute_ratio_error": stats(bbox_ratio_abs_errors),
            "absolute_log_ratio_error": stats(bbox_log_ratio_abs_errors),
            "nonpositive_target_ratio_rows": nonpositive_target_ratios,
        },
        "box3d_Fcam_shapes": dict(fcam_shapes.most_common(20)),
        "positive_depth_rows": positive_depth_rows,
        "invalid_depth_rows": invalid_depth_rows,
    }


def full_frame_ambiguity_report(frame: pd.DataFrame) -> dict[str, Any]:
    required = {"sequence_id", "timestamp_us", "events_path", "event_windows_us", "track_id", "ttc"}
    missing = sorted(required - set(frame.columns))
    if missing:
        return {"available": False, "missing_columns": missing}

    working = frame[
        [
            "sequence_id",
            "timestamp_us",
            "events_path",
            "event_windows_us",
            "track_id",
            "sample_token",
            "ttc",
        ]
    ].copy()
    working["event_signature"] = working["event_windows_us"].map(canonical_nested)
    keys = ["sequence_id", "timestamp_us", "events_path", "event_signature"]
    grouped = working.groupby(keys, dropna=False, sort=False)
    summary = grouped.agg(
        rows=("track_id", "size"),
        distinct_tracks=("track_id", "nunique"),
        distinct_targets=("ttc", "nunique"),
        ttc_min=("ttc", "min"),
        ttc_max=("ttc", "max"),
    ).reset_index()
    summary["ttc_spread"] = summary["ttc_max"] - summary["ttc_min"]
    multi = summary[summary["distinct_tracks"] > 1]
    conflicting = multi[
        (multi["distinct_targets"] > 1)
        & (multi["ttc_spread"].abs() > 1e-9)
    ]
    examples: list[dict[str, Any]] = []
    for _, group_row in conflicting.sort_values(
        ["distinct_tracks", "ttc_spread"],
        ascending=[False, False],
    ).head(20).iterrows():
        mask = np.ones(len(working), dtype=bool)
        for key in keys:
            mask &= working[key].astype(str).to_numpy() == str(group_row[key])
        rows = working.loc[mask].head(20)
        examples.append(
            {
                "sequence_id": str(group_row["sequence_id"]),
                "timestamp_us": int(group_row["timestamp_us"]),
                "events_path": str(group_row["events_path"]),
                "rows": int(group_row["rows"]),
                "distinct_tracks": int(group_row["distinct_tracks"]),
                "ttc_spread": float(group_row["ttc_spread"]),
                "track_targets": [
                    {
                        "track_id": str(item["track_id"]),
                        "sample_token": str(item["sample_token"]),
                        "ttc": float(item["ttc"]),
                    }
                    for _, item in rows.iterrows()
                ],
            }
        )

    return {
        "available": True,
        "input_signature_groups": int(len(summary)),
        "groups_with_multiple_tracks": int(len(multi)),
        "groups_with_conflicting_ttc": int(len(conflicting)),
        "rows_in_conflicting_groups": int(
            conflicting["rows"].sum() if len(conflicting) else 0
        ),
        "max_tracks_for_one_full_frame_input": int(
            multi["distinct_tracks"].max() if len(multi) else 1
        ),
        "ttc_spread_stats_conflicting": (
            {
                "min": float(conflicting["ttc_spread"].min()),
                "median": float(conflicting["ttc_spread"].median()),
                "mean": float(conflicting["ttc_spread"].mean()),
                "max": float(conflicting["ttc_spread"].max()),
            }
            if len(conflicting)
            else {}
        ),
        "examples": examples,
    }


def inspect_hdf5(path: Path, max_datasets: int = 100) -> dict[str, Any]:
    result: dict[str, Any] = {
        "path": str(path),
        "exists": path.is_file(),
    }
    if not path.is_file():
        return result
    result["size_bytes"] = path.stat().st_size
    result["sha256_prefix_64mib"] = None
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        digest.update(handle.read(64 * 1024 * 1024))
    result["sha256_prefix_64mib"] = digest.hexdigest()

    datasets: list[dict[str, Any]] = []
    with h5py.File(path, "r") as handle:
        result["root_attrs"] = {
            str(key): json_safe(value)
            for key, value in handle.attrs.items()
        }

        def visitor(name: str, obj: Any) -> None:
            if isinstance(obj, h5py.Dataset) and len(datasets) < max_datasets:
                item: dict[str, Any] = {
                    "name": name,
                    "shape": list(obj.shape),
                    "dtype": str(obj.dtype),
                    "compression": str(obj.compression),
                    "attrs": {
                        str(key): json_safe(value)
                        for key, value in obj.attrs.items()
                    },
                }
                if obj.size and obj.ndim == 1 and obj.dtype.kind in "iufb":
                    indices = sorted(set([0, obj.shape[0] // 2, obj.shape[0] - 1]))
                    try:
                        item["sample_values"] = [
                            json_safe(obj[index]) for index in indices
                        ]
                    except Exception as exc:
                        item["sample_error"] = str(exc)
                datasets.append(item)

        handle.visititems(visitor)
    result["datasets"] = datasets
    return result


def resolve_referenced_path(root: Path, value: Any) -> Path:
    raw = Path(str(value))
    candidates = [
        raw,
        root / raw,
        root / raw.name,
        root / "data" / raw,
    ]
    for candidate in candidates:
        if candidate.is_file():
            return candidate.resolve()
    return (root / raw).resolve()


def referenced_asset_report(frame: pd.DataFrame, eap_root: Path, sample_rows: int) -> dict[str, Any]:
    result: dict[str, Any] = {}
    subset = frame.head(min(sample_rows, len(frame)))

    if "events_path" in frame.columns:
        event_values = list(dict.fromkeys(str(value) for value in subset["events_path"].dropna()))
        inspected = []
        for value in event_values[:3]:
            path = resolve_referenced_path(eap_root, value)
            try:
                inspected.append(inspect_hdf5(path))
            except Exception:
                inspected.append(
                    {
                        "path": str(path),
                        "exists": path.is_file(),
                        "error": traceback.format_exc(),
                    }
                )
        result["event_files"] = {
            "sample_unique_references": event_values[:20],
            "inspected": inspected,
        }

    rgb_checks: list[dict[str, Any]] = []
    if {"rgb_shard_paths", "rgb_member_paths"}.issubset(frame.columns):
        for _, row in subset.head(20).iterrows():
            shards = to_python(row["rgb_shard_paths"])
            members = to_python(row["rgb_member_paths"])
            if not isinstance(shards, (list, tuple)) or not isinstance(members, (list, tuple)):
                continue
            for shard, member in list(zip(shards, members))[:2]:
                shard_path = resolve_referenced_path(eap_root, shard)
                item = {
                    "shard": str(shard),
                    "resolved": str(shard_path),
                    "exists": shard_path.is_file(),
                    "member": str(member),
                    "member_exists": None,
                }
                if shard_path.is_file():
                    try:
                        with tarfile.open(shard_path, "r") as archive:
                            item["member_exists"] = archive.getmember(str(member)) is not None
                    except Exception as exc:
                        item["member_error"] = str(exc)
                rgb_checks.append(item)
                if len(rgb_checks) >= 20:
                    break
            if len(rgb_checks) >= 20:
                break
    result["rgb_reference_checks"] = rgb_checks
    result["mask_related_columns"] = [
        column
        for column in frame.columns
        if "mask" in column.lower() or "seg" in column.lower()
    ]
    return result


def source_snapshot(repo_root: Path, output_dir: Path) -> dict[str, Any]:
    snapshot_root = output_dir / "source_snapshot"
    hashes: dict[str, Any] = {}
    for relative in SOURCE_SNAPSHOT_PATHS:
        source = repo_root / relative
        if not source.is_file():
            hashes[relative] = {"exists": False}
            continue
        destination = snapshot_root / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)
        hashes[relative] = {
            "exists": True,
            "sha256": sha256_file(source),
            "size_bytes": source.stat().st_size,
        }

    for directory in [
        repo_root / "configs" / "model",
        repo_root / "configs" / "train",
        repo_root / "configs" / "experiment",
    ]:
        if not directory.is_dir():
            continue
        for source in sorted(directory.glob("*tubelet*lhr*.yaml")):
            relative = source.relative_to(repo_root)
            destination = snapshot_root / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, destination)
            hashes[str(relative).replace("\\", "/")] = {
                "exists": True,
                "sha256": sha256_file(source),
                "size_bytes": source.stat().st_size,
            }
    return hashes


def write_summary(report: dict[str, Any], path: Path) -> None:
    ambiguity = report["dataset"]["full_frame_ambiguity"]
    align = report["dataset"]["alignment"]
    geometry = report["dataset"]["bbox_and_geometry"]
    lines = [
        "# Auditoría eAP/GarlTTC object-centric",
        "",
        f"- Commit: `{report['repository']['commit']}`",
        f"- Rama: `{report['repository']['branch']}`",
        f"- Git sucio: `{report['repository']['dirty']}`",
        f"- Filas data: `{report['dataset']['data_schema']['rows']}`",
        f"- Filas annotations: `{report['dataset']['annotation_schema']['rows']}`",
        f"- Filas merged: `{report['dataset']['merged_schema']['rows']}`",
        "",
        "## Ambigüedad del input full-frame",
        "",
        f"- Grupos con varios tracks: `{ambiguity.get('groups_with_multiple_tracks')}`",
        f"- Grupos con TTC conflictivo: `{ambiguity.get('groups_with_conflicting_ttc')}`",
        f"- Filas dentro de grupos conflictivos: `{ambiguity.get('rows_in_conflicting_groups')}`",
        f"- Máximo de tracks para el mismo input full-frame: `{ambiguity.get('max_tracks_for_one_full_frame_input')}`",
        "",
        "## Alineación de campos",
        "",
        "```json",
        json.dumps(align["pairwise_alignment"], indent=2, ensure_ascii=False),
        "```",
        "",
        "## Geometría",
        "",
        f"- Cajas auditadas: `{geometry['total_boxes']}`",
        f"- Cajas inválidas: `{geometry['invalid_boxes']}`",
        f"- Filas comparables bbox-ratio/TTC: `{geometry['bbox_height_ratio_vs_ttc']['comparable_rows']}`",
        f"- Filas con profundidad 3D positiva: `{geometry['positive_depth_rows']}`",
        f"- Filas con profundidad 3D inválida: `{geometry['invalid_depth_rows']}`",
        "",
        "Sube el ZIP completo generado por este script; no basta con copiar solo este resumen.",
        "",
    ]
    path.write_text("\n".join(lines), encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", type=Path, default=Path.cwd())
    parser.add_argument("--eap-root", type=Path, required=True)
    parser.add_argument("--garlttc-root", type=Path, required=True)
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("artifacts/debug/eap_garl_objectcentric_audit"),
    )
    parser.add_argument("--geometry-row-limit", type=int, default=20000)
    parser.add_argument("--asset-sample-rows", type=int, default=100)
    parser.add_argument("--target-delta-s", type=float, default=0.1)
    args = parser.parse_args()

    repo_root = args.repo_root.resolve()
    eap_root = args.eap_root.resolve()
    garl_root = args.garlttc_root.resolve()
    output_dir = (repo_root / args.output_dir).resolve() if not args.output_dir.is_absolute() else args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    data_path = locate_parquet(
        garl_root,
        ["data/train.parquet", "train_inputs.parquet", "train.parquet"],
        "train.parquet",
    )
    annotation_path = locate_parquet(
        garl_root,
        ["annotations/train.parquet", "train_annotations.parquet"],
        "train.parquet",
    )
    if data_path == annotation_path:
        candidates = sorted(garl_root.rglob("train.parquet"))
        annotation_candidates = [
            item for item in candidates if "annotation" in item.as_posix().lower()
        ]
        data_candidates = [
            item for item in candidates if "data" in item.as_posix().lower()
        ]
        if annotation_candidates and data_candidates:
            data_path = data_candidates[0].resolve()
            annotation_path = annotation_candidates[0].resolve()
        else:
            raise RuntimeError(
                "No se pudo distinguir data/train.parquet de annotations/train.parquet"
            )

    print(f"Reading {data_path}", flush=True)
    data_df = pd.read_parquet(data_path)
    print(f"Reading {annotation_path}", flush=True)
    annotation_df = pd.read_parquet(annotation_path)

    for key in JOIN_KEYS:
        if key not in data_df.columns:
            raise ValueError(f"Falta join key {key!r} en {data_path}")
        if key not in annotation_df.columns:
            raise ValueError(f"Falta join key {key!r} en {annotation_path}")

    duplicate_data = int(data_df.duplicated(JOIN_KEYS, keep=False).sum())
    duplicate_annotations = int(annotation_df.duplicated(JOIN_KEYS, keep=False).sum())
    merged = data_df.merge(
        annotation_df,
        on=JOIN_KEYS,
        how="inner",
        validate="one_to_one",
        suffixes=("_data", "_annotation"),
    )
    if "ttc" not in merged.columns:
        for candidate in ["ttc_annotation", "ttc_time", "ttc_time_annotation"]:
            if candidate in merged.columns:
                merged["ttc"] = merged[candidate]
                break
    if "boxes_xyxy" not in merged.columns:
        for candidate in ["boxes_xyxy_annotation", "boxes_xyxy_data"]:
            if candidate in merged.columns:
                merged["boxes_xyxy"] = merged[candidate]
                break
    for field in NESTED_FIELDS + ["events_path"]:
        if field not in merged.columns:
            for candidate in [f"{field}_data", f"{field}_annotation"]:
                if candidate in merged.columns:
                    merged[field] = merged[candidate]
                    break

    git_commit = run_command(["git", "rev-parse", "HEAD"], repo_root)
    git_branch = run_command(["git", "branch", "--show-current"], repo_root)
    git_status = run_command(["git", "status", "--short"], repo_root)
    git_diff = run_command(["git", "diff", "--binary"], repo_root)
    git_diff_cached = run_command(["git", "diff", "--cached", "--binary"], repo_root)

    (output_dir / "git_status.txt").write_text(
        git_status["stdout"] + git_status["stderr"],
        encoding="utf-8",
    )
    (output_dir / "local_changes.patch").write_text(
        git_diff["stdout"],
        encoding="utf-8",
    )
    (output_dir / "staged_changes.patch").write_text(
        git_diff_cached["stdout"],
        encoding="utf-8",
    )

    report: dict[str, Any] = {
        "artifact_type": "eap_garl_objectcentric_patch_audit_v1",
        "repository": {
            "root": str(repo_root),
            "commit": git_commit["stdout"].strip(),
            "branch": git_branch["stdout"].strip(),
            "dirty": bool(git_status["stdout"].strip()),
            "status": git_status["stdout"].splitlines(),
        },
        "environment": {
            "python": sys.version,
            "platform": sys.platform,
            "eap_root": str(eap_root),
            "garlttc_root": str(garl_root),
        },
        "dataset": {
            "data_path": str(data_path),
            "annotation_path": str(annotation_path),
            "data_sha256": sha256_file(data_path),
            "annotation_sha256": sha256_file(annotation_path),
            "data_schema": dataframe_schema(data_df),
            "annotation_schema": dataframe_schema(annotation_df),
            "merged_schema": dataframe_schema(merged),
            "duplicate_join_rows_data": duplicate_data,
            "duplicate_join_rows_annotations": duplicate_annotations,
            "join": {
                "inner_rows": int(len(merged)),
                "data_rows": int(len(data_df)),
                "annotation_rows": int(len(annotation_df)),
                "complete_one_to_one": (
                    len(merged) == len(data_df) == len(annotation_df)
                    and duplicate_data == 0
                    and duplicate_annotations == 0
                ),
            },
            "alignment": alignment_report(merged),
            "bbox_and_geometry": bbox_and_geometry_report(
                merged,
                row_limit=args.geometry_row_limit,
                target_delta_s=args.target_delta_s,
            ),
            "full_frame_ambiguity": full_frame_ambiguity_report(merged),
            "referenced_assets": referenced_asset_report(
                merged,
                eap_root=eap_root,
                sample_rows=args.asset_sample_rows,
            ),
        },
        "source_snapshot": source_snapshot(repo_root, output_dir),
    }

    report_path = output_dir / "audit.json"
    report_path.write_text(
        json.dumps(json_safe(report), indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    summary_path = output_dir / "SUMMARY.md"
    write_summary(report, summary_path)

    zip_path = output_dir.with_suffix(".zip")
    if zip_path.exists():
        zip_path.unlink()
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(output_dir.rglob("*")):
            if path.is_file():
                archive.write(path, path.relative_to(output_dir).as_posix())

    print("\n===== AUDIT COMPLETE =====")
    print(summary_path.read_text(encoding="utf-8"))
    print(f"ZIP: {zip_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
