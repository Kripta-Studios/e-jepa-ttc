#!/usr/bin/env python
"""Read-only perturbation audit for Object-Signed-Expansion v3.

Evaluates best.pt for scratch and Level-transfer under controlled input
perturbations. It does not train, modify checkpoints, or touch cache shards.

Modes:
- full: original model inputs.
- prior_only: deterministic observable box-height prior.
- motion_only: zero event tensors; retain observable and context motion.
- event_only: zero observable/context motion; retain ordered event ROIs.
- shuffled_events: rotate event pairs across samples; retain each sample's motion.
- reversed_events_only: reverse event endpoints but retain original motion.
- height_rate_only: retain only observable log-height-rate (index 7).
- no_precontext: remove precontext motion while preserving endpoint motion.
"""

from __future__ import annotations

import argparse
import json
import math
import sys
from functools import partial
from dataclasses import fields
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import torch
from torch.utils.data import DataLoader

ROOT = Path.cwd().resolve()
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "src"))

from e_jepa_ttc.data.object_signed_expansion import (  # noqa: E402
    GarlTTCObjectSignedExpansionDataset,
    ObjectSignedExpansionBatch,
    collate_object_signed_expansion,
)
from e_jepa_ttc.models.object_signed_expansion import (  # noqa: E402
    LOG_HEIGHT_RATE_INDEX,
    ObjectCentricSignedExpansionTTC,
    ObjectSignedExpansionConfig,
    geometry_prior_from_motion,
    safe_ttc_from_expansion,
)
from e_jepa_ttc.training.object_signed_expansion import (  # noqa: E402
    ObjectSignedExpansionLossConfig,
    targets_from_batch,
)
from e_jepa_ttc.training.tubelet_finetuning import prediction_health  # noqa: E402
from scripts.train_e_jepa_object_signed_expansion import (  # noqa: E402
    ObjectSignedExpansionTrainConfig,
    _class_metrics,
    _metrics,
)


MODES = (
    "full",
    "prior_only",
    "motion_only",
    "event_only",
    "shuffled_events",
    "reversed_events_only",
    "height_rate_only",
    "no_precontext",
)


def _filtered_dataclass(cls: type[Any], value: dict[str, Any]) -> Any:
    names = {item.name for item in fields(cls)}
    return cls(**{key: item for key, item in value.items() if key in names})


def _json_safe(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, bool)):
        return value
    if isinstance(value, float):
        return value if math.isfinite(value) else None
    if isinstance(value, np.generic):
        return _json_safe(value.item())
    if isinstance(value, np.ndarray):
        return [_json_safe(item) for item in value.tolist()]
    if isinstance(value, dict):
        return {str(key): _json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(item) for item in value]
    return str(value)


def _close_dataset(dataset: Any) -> None:
    close_fn = getattr(dataset, "close", None)
    if callable(close_fn):
        close_fn()
        return
    inner = getattr(dataset, "_dataset", None)
    inner_close = getattr(inner, "close", None)
    if callable(inner_close):
        inner_close()


def _load_model(
    run_dir: Path,
    device: torch.device,
) -> tuple[
    ObjectCentricSignedExpansionTTC,
    ObjectSignedExpansionTrainConfig,
    ObjectSignedExpansionLossConfig,
    dict[str, Any],
]:
    summary = json.loads((run_dir / "summary.json").read_text(encoding="utf-8"))
    checkpoint = torch.load(
        run_dir / "best.pt",
        map_location="cpu",
        weights_only=False,
    )
    if checkpoint.get("artifact_type") != "e_jepa_object_signed_expansion_checkpoint_v3":
        raise ValueError(f"Unexpected checkpoint artifact in {run_dir}")
    model_config = _filtered_dataclass(
        ObjectSignedExpansionConfig,
        dict(checkpoint["model_config"]),
    )
    train_config = _filtered_dataclass(
        ObjectSignedExpansionTrainConfig,
        dict(checkpoint["train_config"]),
    )
    loss_config = _filtered_dataclass(
        ObjectSignedExpansionLossConfig,
        dict(checkpoint["loss_config"]),
    )
    model = ObjectCentricSignedExpansionTTC(model_config)
    model.load_state_dict(checkpoint["model_state_dict"], strict=True)
    model.to(device)
    model.eval()
    return model, train_config, loss_config, summary


def _transform(
    batch: ObjectSignedExpansionBatch,
    mode: str,
) -> dict[str, torch.Tensor]:
    inputs = batch.model_inputs()
    events = inputs["events"]
    observable = inputs["observable_motion"]
    context = inputs["jepa_context_motion"]
    valid = inputs["precontext_motion_valid"]

    if mode in {"full", "prior_only"}:
        return inputs
    if mode == "motion_only":
        return {
            **inputs,
            "events": torch.zeros_like(events),
        }
    if mode == "event_only":
        return {
            **inputs,
            "observable_motion": torch.zeros_like(observable),
            "jepa_context_motion": torch.zeros_like(context),
            "precontext_motion_valid": torch.zeros_like(valid),
        }
    if mode == "shuffled_events":
        if events.shape[0] > 1:
            events = torch.roll(events, shifts=1, dims=0)
        else:
            events = torch.flip(events, dims=(1,))
        return {**inputs, "events": events}
    if mode == "reversed_events_only":
        return {**inputs, "events": torch.flip(events, dims=(1,))}
    if mode == "height_rate_only":
        reduced = torch.zeros_like(observable)
        reduced[:, LOG_HEIGHT_RATE_INDEX] = observable[:, LOG_HEIGHT_RATE_INDEX]
        return {
            **inputs,
            "observable_motion": reduced,
            "jepa_context_motion": torch.zeros_like(context),
            "precontext_motion_valid": torch.zeros_like(valid),
        }
    if mode == "no_precontext":
        return {
            **inputs,
            "jepa_context_motion": torch.zeros_like(context),
            "precontext_motion_valid": torch.zeros_like(valid),
        }
    raise ValueError(f"Unknown mode: {mode}")


@torch.no_grad()
def _evaluate_mode(
    model: ObjectCentricSignedExpansionTTC,
    loader: DataLoader[ObjectSignedExpansionBatch],
    *,
    mode: str,
    device: torch.device,
    loss_config: ObjectSignedExpansionLossConfig,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for raw_batch in loader:
        batch = raw_batch.to(device)
        targets = targets_from_batch(batch, loss_config)
        inputs = _transform(batch, mode)

        if mode == "prior_only":
            expansion, _ = geometry_prior_from_motion(
                inputs["observable_motion"],
                batch.delta_t_s,
                log_rate_scale=model.config.box_log_rate_scale,
                max_abs_expansion=model.config.max_abs_expansion,
            )
            ttc = safe_ttc_from_expansion(
                expansion,
                batch.delta_t_s,
                minimum_abs_expansion=model.config.min_abs_expansion_for_ttc,
                clip_seconds=model.config.ttc_clip_seconds,
            )
            residual = torch.zeros_like(expansion)
        else:
            output = model(**inputs)
            expansion = output.signed_expansion
            ttc = output.ttc_mean_seconds
            residual = output.learned_residual_expansion

        for index in range(len(batch.sample_tokens)):
            rows.append(
                {
                    "sample_token": batch.sample_tokens[index],
                    "sequence_id": batch.sequence_ids[index],
                    "track_id": batch.track_ids[index],
                    "target_ttc_s": float(batch.target_ttc_s[index].cpu()),
                    "prediction_ttc_s": float(ttc[index].cpu()),
                    "target_signed_expansion": float(
                        targets.signed_expansion[index].cpu()
                    ),
                    "prediction_signed_expansion": float(expansion[index].cpu()),
                    "learned_residual_expansion": float(residual[index].cpu()),
                }
            )

    frame = pd.DataFrame.from_records(rows)
    target_ttc = frame["target_ttc_s"].to_numpy(dtype=np.float64)
    prediction_ttc = frame["prediction_ttc_s"].to_numpy(dtype=np.float64)
    target_expansion = frame["target_signed_expansion"].to_numpy(dtype=np.float64)
    prediction_expansion = frame["prediction_signed_expansion"].to_numpy(
        dtype=np.float64
    )
    metrics = _metrics(frame)
    direction = _class_metrics(target_expansion, prediction_expansion)
    saturation = float(
        np.mean(
            np.abs(prediction_ttc)
            >= model.config.ttc_clip_seconds * (1.0 - 1.0e-6)
        )
    )
    result = {
        "metrics": metrics,
        "expansion_health": prediction_health(
            target_expansion,
            prediction_expansion,
        ),
        "ttc_health": prediction_health(target_ttc, prediction_ttc),
        "direction": direction,
        "saturation_rate": saturation,
        "residual_abs_mean": float(
            np.mean(np.abs(frame["learned_residual_expansion"]))
        ),
    }
    return frame, result


def _compact(arm: str, mode: str, result: dict[str, Any]) -> dict[str, Any]:
    metrics = result["metrics"]
    macro = metrics["sequence_macro"]["sequence_macro_paper_MiD_overall"]
    return {
        "arm": arm,
        "mode": mode,
        "macro_mid": macro,
        "global_mid": metrics["paper_MiD_overall"],
        "negative_mid": metrics["bins"]["negative"]["mid"],
        "crucial_mid": metrics["bins"]["crucial"]["mid"],
        "small_mid": metrics["bins"]["small"]["mid"],
        "large_mid": metrics["bins"]["large"]["mid"],
        "mae_s": metrics["mae_s"],
        "median_ae_s": metrics["median_ae_s"],
        "expansion_pearson": result["expansion_health"]["pearson"],
        "expansion_mae": result["expansion_health"]["mae"],
        "balanced_sign_accuracy": result["direction"]["balanced_accuracy"],
        "negative_recall": result["direction"]["negative_recall"],
        "sign_auc": result["direction"]["auc"],
        "saturation_rate": result["saturation_rate"],
        "residual_abs_mean": result["residual_abs_mean"],
    }


def _audit_arm(
    arm: str,
    run_dir: Path,
    manifest: Path,
    output_dir: Path,
    device: torch.device,
) -> dict[str, Any]:
    print(f"\n===== {arm} =====", flush=True)
    model, train_config, loss_config, summary = _load_model(run_dir, device)
    dataset = GarlTTCObjectSignedExpansionDataset(
        str(manifest.resolve()),
        splits=("validation",),
        event_field=train_config.event_field,
    )
    try:
        loader = DataLoader(
            dataset,
            batch_size=train_config.batch_size,
            shuffle=False,
            num_workers=train_config.num_workers,
            pin_memory=True,
            persistent_workers=train_config.num_workers > 0,
            collate_fn=partial(
                collate_object_signed_expansion,
                event_field=train_config.event_field,
            ),
        )
        mode_results: dict[str, Any] = {}
        compact_rows: list[dict[str, Any]] = []
        for mode in MODES:
            print(f"Evaluating {arm}/{mode}...", flush=True)
            frame, result = _evaluate_mode(
                model,
                loader,
                mode=mode,
                device=device,
                loss_config=loss_config,
            )
            frame.to_csv(
                output_dir / f"{arm}_{mode}_predictions.csv",
                index=False,
            )
            mode_results[mode] = result
            compact_rows.append(_compact(arm, mode, result))
    finally:
        _close_dataset(dataset)

    return {
        "arm": arm,
        "run_dir": run_dir.resolve().as_posix(),
        "best_epoch": summary["best_epoch"],
        "pretraining": summary["pretraining"],
        "modes": mode_results,
        "compact_rows": compact_rows,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--scratch-dir", type=Path, required=True)
    parser.add_argument("--transfer-dir", type=Path, required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--device", default="cuda")
    args = parser.parse_args()

    if args.device.startswith("cuda") and not torch.cuda.is_available():
        raise RuntimeError("CUDA requested but torch.cuda.is_available() is false")

    device = torch.device(args.device)
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    result = {
        "artifact_type": "object_signed_expansion_v3_perturbation_audit_v1",
        "manifest": args.manifest.resolve().as_posix(),
        "device": str(device),
        "arms": [
            _audit_arm(
                "scratch",
                args.scratch_dir,
                args.manifest,
                output_dir,
                device,
            ),
            _audit_arm(
                "level-transfer",
                args.transfer_dir,
                args.manifest,
                output_dir,
                device,
            ),
        ],
    }

    rows = [
        row
        for arm in result["arms"]
        for row in arm["compact_rows"]
    ]
    result["summary"] = rows
    (output_dir / "perturbation_diagnostics.json").write_text(
        json.dumps(_json_safe(result), indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    pd.DataFrame(rows).to_csv(
        output_dir / "perturbation_summary.csv",
        index=False,
    )
    print("\n===== SUMMARY =====")
    print(pd.DataFrame(rows).to_string(index=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
