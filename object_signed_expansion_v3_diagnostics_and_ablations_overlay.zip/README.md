# Object-Signed-Expansion v3 diagnostics and ablations

Read-only perturbation diagnostics plus YAML generators and result collector.
No cache rebuild is required.
