"""Run the full MonoDGP portable variant without external CUDA compilation.

This is a synthetic software check, not an eAP evaluation or pretrained model.
Source changes are generated from a fixed upstream revision and saved as a patch.
The functions build_detector and decode_native are reusable by bounded pilots.
"""

# ruff: noqa: E402 -- allow direct script execution from an uninstalled worktree.

from __future__ import annotations

import argparse
import difflib
import hashlib
import json
import shutil
import subprocess
import sys
import time
import traceback
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

import numpy as np
import torch
import yaml

REVISION = "aa059a18214aebf644510e7f0793971b403f9d14"
VARIANT = "monodgp_pytorch_grid_sample_v1"


def sha256(path: Path) -> str:
    """Hash a local reproducibility artifact."""
    return hashlib.sha256(path.read_bytes()).hexdigest()


def prepare_source(source: Path, destination: Path, patch_path: Path) -> dict[str, Any]:
    """Prepare a separate source copy; fail if the pinned source or recipe changes."""
    observed = subprocess.check_output(
        ["git", "-C", str(source), "rev-parse", "HEAD"], text=True
    ).strip()
    if observed != REVISION:
        raise ValueError(f"Expected MonoDGP {REVISION}, found {observed}.")
    if subprocess.check_output(["git", "-C", str(source), "diff", "HEAD", "--"], text=True):
        raise ValueError("Pinned source must have no tracked changes.")
    marker = destination / ".portable_source.json"
    if destination.exists() and not marker.exists():
        raise FileExistsError(f"Refusing to overwrite an unmanaged directory: {destination}")
    destination.mkdir(parents=True, exist_ok=True)
    marker.write_text(json.dumps({"upstream": REVISION, "variant": VARIANT}), encoding="utf-8")
    for folder in ("lib", "utils", "configs"):
        shutil.copytree(
            source / folder,
            destination / folder,
            dirs_exist_ok=True,
            ignore=shutil.ignore_patterns("__pycache__", "*.pyc"),
        )
    shutil.copy2(source / "LICENSE", destination / "LICENSE")
    patches: list[str] = []
    changes: list[dict[str, str]] = []

    def edit(relative: str, before: str, after: str) -> None:
        path = destination / relative
        original = path.read_text(encoding="utf-8")
        if original.count(before) != 1:
            raise ValueError(f"Patch anchor is not unique: {relative}: {before[:70]}")
        modified = original.replace(before, after, 1)
        path.write_text(modified, encoding="utf-8", newline="\n")
        patches.extend(
            difflib.unified_diff(
                original.splitlines(keepends=True),
                modified.splitlines(keepends=True),
                fromfile=f"a/{relative}",
                tofile=f"b/{relative}",
            )
        )
        changes.append({"path": relative, "after_sha256": sha256(path)})

    base = "lib/models/monodgp/"
    relative = base + "ops/functions/ms_deform_attn_func.py"
    original = (destination / relative).read_text(encoding="utf-8")
    start = original.index("import MultiScaleDeformableAttention as MSDA")
    end = original.index("def ms_deform_attn_core_pytorch")
    edit(
        relative,
        original[start:end],
        "from e_jepa_ttc.detection.portable_attention import (\n"
        "    PortableMSDeformAttnFunction as MSDeformAttnFunction,\n)\n\n\n",
    )
    relative = base + "ops/modules/ms_deform_attn.py"
    original = (destination / relative).read_text(encoding="utf-8")
    start = original.index("if float(torch.__version__")
    end = original.index("from torch.nn.init import xavier_uniform_", start)
    edit(
        relative,
        original[start:end],
        "from torch.nn.modules.linear import NonDynamicallyQuantizableLinear as _LinearWithBias\n",
    )
    original = (destination / relative).read_text(encoding="utf-8")
    start = original.index("if float(torch.__version__")
    end = original.index("Tensor = torch.Tensor", start)
    edit(
        relative,
        original[start:end],
        "from torch.overrides import has_torch_function, handle_torch_function\n",
    )
    edit(
        base + "backbone.py",
        "pretrained=is_main_process(), norm_layer=norm_layer",
        "weights=None, norm_layer=norm_layer",
    )
    for name, last in (("det2d", "enc_n_points"), ("det3d", "dec_n_points")):
        edit(
            base + name + "_transformer.py",
            f"{last}=cfg['{last}'])",
            f"{last}=cfg['{last}'], group_num=cfg['group_num'])",
        )
    edit(
        base + "monodgp.py",
        "torch.zeros(heading_target_cls.shape[0], 12).cuda()",
        "torch.zeros(heading_target_cls.shape[0], 12, device=heading_target_cls.device)",
    )
    edit(
        base + "monodgp.py",
        "torch.tensor([80, 24, 80, 24], device='cuda')",
        "depth_map_logits.new_tensor([depth_map_logits.shape[-1], depth_map_logits.shape[-2], "
        "depth_map_logits.shape[-1], depth_map_logits.shape[-2]])",
    )
    edit(base + "monodgp.py", "* calibs[:, 0, 0].unsqueeze(1)", "* calibs[:, 1, 1].unsqueeze(1)")
    edit(
        base + "monodgp.py",
        "src_dims = outputs['pred_3d_dim'][idx]",
        "src_dims = outputs['pred_3d_dim'][idx]\n"
        "        if src_dims.numel() == 0:\n"
        "            return {'loss_dim': src_dims.sum() * 0.0}",
    )
    edit(
        base + "matcher.py",
        "C = torch.nan_to_num(C, nan=0.0, posinf=0.0, neginf=0.0)",
        "if not torch.isfinite(C).all():\n"
        "            raise ValueError('Nonfinite matching costs before assignment')",
    )
    patch_path.parent.mkdir(parents=True, exist_ok=True)
    patch_path.write_text("".join(patches), encoding="utf-8", newline="\n")
    final_hashes = {item["path"]: sha256(destination / item["path"]) for item in changes}
    receipt = {
        "upstream_revision": observed,
        "variant": VARIANT,
        "patch_sha256": sha256(patch_path),
        "patched_file_sha256": final_hashes,
        "external_extension_used": False,
        "automatic_pretrained_download": False,
    }
    marker.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    return receipt


def build_detector(source: Path, group_num: int = 11) -> tuple[Any, Any, dict[str, Any]]:
    """Build all original detector modules, eight classes, without pretrained weights."""
    sys.path.insert(0, str(source.resolve()))
    from lib.models.monodgp import build

    config = yaml.safe_load((source / "configs/monodgp.yaml").read_text(encoding="utf-8"))["model"]
    config.update(num_classes=8, group_num=group_num, device="cuda")
    model, criterion = build(config)
    return model.cuda(), criterion.cuda(), config


def make_fixture(
    height: int, width: int
) -> tuple[torch.Tensor, torch.Tensor, list[dict], torch.Tensor]:
    """Construct eight synthetic positive targets, one per class, in camera coordinates."""
    device = torch.device("cuda")
    images = torch.rand(1, 3, height, width, device=device)
    xy = torch.tensor(
        [[0.15 + 0.23 * (i % 4), 0.35 + 0.3 * (i // 4)] for i in range(8)], device=device
    )
    wh = torch.tensor([[0.10 + 0.005 * i, 0.15 + 0.01 * i] for i in range(8)], device=device)
    boxes = torch.cat((xy, wh), dim=1)
    extents = torch.stack((wh[:, 0] / 2, wh[:, 0] / 2, wh[:, 1] / 2, wh[:, 1] / 2), dim=1)
    region = torch.zeros(height, width, device=device)
    for box in boxes.cpu().tolist():
        x, y, w, h = box
        region[
            int((y - h / 2) * height) : int((y + h / 2) * height),
            int((x - w / 2) * width) : int((x + w / 2) * width),
        ] = 1
    targets = [
        {
            "labels": torch.arange(8, device=device),
            "boxes": boxes,
            "boxes_3d": torch.cat((xy, extents), dim=1),
            "depth": torch.linspace(8, 22, 8, device=device).unsqueeze(1),
            "size_3d": torch.tensor([[1.5 + i * 0.1, 1.8, 4.0] for i in range(8)], device=device),
            "heading_bin": torch.arange(8, device=device).unsqueeze(1),
            "heading_res": torch.linspace(-0.1, 0.1, 8, device=device).unsqueeze(1),
            "obj_region": region,
        }
    ]
    calibration = torch.tensor(
        [[[0.75 * width, 0, width / 2, 0], [0, 1.8 * height, height / 2, 0], [0, 0, 1, 0]]],
        device=device,
    )
    image_sizes = torch.tensor([[width, height]], dtype=torch.float32, device=device)
    return images, calibration, targets, image_sizes


def require_finite(value: Any, name: str = "output") -> None:
    """Reject nonfinite tensors recursively, before any target matcher sanitization."""
    if isinstance(value, torch.Tensor) and not torch.isfinite(value).all().item():
        raise ValueError(f"Nonfinite tensor: {name}")
    if isinstance(value, dict):
        for key, item in value.items():
            require_finite(item, f"{name}.{key}")
    if isinstance(value, (list, tuple)):
        for index, item in enumerate(value):
            require_finite(item, f"{name}[{index}]")


def decode_native(outputs: dict, calibration: torch.Tensor, image_sizes: torch.Tensor) -> dict:
    """Exercise upstream native KITTI decoding; do not claim the eAP coordinate contract."""
    from lib.helpers.decode_helper import decode_detections, extract_dets_from_outputs

    class PinholeCalibration:
        def __init__(self, matrix: np.ndarray) -> None:
            self.matrix = matrix

        def img_to_rect(self, u: float, v: float, depth: float) -> np.ndarray:
            k = self.matrix
            return np.array(
                [[(u - k[0, 2]) * depth / k[0, 0], (v - k[1, 2]) * depth / k[1, 1], depth]]
            )

        def alpha2ry(self, alpha: float, u: float) -> float:
            yaw = alpha + np.arctan2(u - self.matrix[0, 2], self.matrix[0, 0])
            return float((yaw + np.pi) % (2 * np.pi) - np.pi)

    dets = extract_dets_from_outputs(outputs, topk=50).detach().cpu().numpy()
    info = {"img_size": image_sizes.cpu().numpy(), "img_id": list(range(len(dets)))}
    decoded = decode_detections(
        dets.copy(),
        info,
        [PinholeCalibration(k) for k in calibration.cpu().numpy()],
        np.zeros((8, 3), dtype=np.float32),
        threshold=0.0,
    )
    array = np.asarray(decoded[0], dtype=float)
    if array.shape != (50, 14) or not np.isfinite(array).all():
        raise ValueError(f"Invalid native decode shape/finiteness: {array.shape}")
    return {
        "scope": "synthetic_camera_native_kitti_not_eap_submission",
        "rows": array.tolist(),
        "shape": list(array.shape),
        "all_finite": True,
        "positive_dimensions_count": int((array[:, 6:9] > 0).all(axis=1).sum()),
        "positive_depth_count": int((array[:, 11] > 0).sum()),
        "velocity_head": "ABSENT",
        "score_policy": "native_class_sigmoid_times_exp_neg_log_variance",
    }


def run(args: argparse.Namespace, report: dict[str, Any]) -> None:
    """Execute full model train/eval and record resource measurements."""
    if not torch.cuda.is_available():
        raise RuntimeError("A CUDA device is required for this G1 portable smoke.")
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    torch.set_num_threads(4)
    report.update(
        {
            "created_at_utc": datetime.now(UTC).isoformat(),
            "variant": VARIANT,
            "torch": torch.__version__,
            "cuda": torch.version.cuda,
            "device": torch.cuda.get_device_name(),
            "seed": args.seed,
            "image_hw": [args.height, args.width],
            "batch_size": 1,
            "scope": "synthetic_full_detector_software_not_eap_accuracy",
            "native_compiled_g1": "BLOCKED_UNCHANGED",
            "steps": [],
        }
    )
    report["runner_sha256"] = sha256(Path(__file__))
    report["portable_operator_sha256"] = sha256(
        ROOT / "src/e_jepa_ttc/detection/portable_attention.py"
    )
    report["git_commit"] = subprocess.check_output(
        ["git", "-C", str(ROOT), "rev-parse", "HEAD"], text=True
    ).strip()
    report["source"] = prepare_source(
        args.source_root, args.portable_root, args.output.with_suffix(".patch")
    )
    model, criterion, config = build_detector(args.portable_root, args.group_num)
    print(
        json.dumps({"stage": "model_built", "variant": VARIANT, "group_num": args.group_num}),
        flush=True,
    )
    report["config"] = config
    report["parameter_count"] = sum(parameter.numel() for parameter in model.parameters())
    images, calibration, targets, image_sizes = make_fixture(args.height, args.width)
    optimizer = torch.optim.AdamW((p for p in model.parameters() if p.requires_grad), lr=1e-4)
    torch.cuda.reset_peak_memory_stats()
    model.train()
    criterion.train()
    for step in range(args.steps):
        optimizer.zero_grad(set_to_none=True)
        torch.cuda.synchronize()
        started = time.perf_counter()
        outputs = model(images, calibration, targets, image_sizes)
        require_finite(outputs)
        losses = criterion(outputs, targets)
        require_finite(losses, "losses")
        loss = sum(
            value * criterion.weight_dict[key]
            for key, value in losses.items()
            if key in criterion.weight_dict
        )
        torch.cuda.synchronize()
        forward_done = time.perf_counter()
        loss.backward()
        gradients = [p.grad for p in model.parameters() if p.grad is not None]
        if not gradients or not all(torch.isfinite(g).all().item() for g in gradients):
            raise ValueError("Missing or nonfinite parameter gradients.")
        grad_norm = torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        active_class_head = model.class_embed[config["dec_layers"] - 1]
        before = active_class_head.weight.detach().clone()
        torch.cuda.synchronize()
        backward_done = time.perf_counter()
        optimizer.step()
        changed = not torch.equal(before, active_class_head.weight)
        if not changed:
            raise ValueError("Optimizer did not update the final classification head.")
        torch.cuda.synchronize()
        step_done = time.perf_counter()
        record = {
            "step": step,
            "loss": float(loss.detach()),
            "gradient_norm_before_clip": float(grad_norm),
            "parameter_update": changed,
            "parameters_with_gradient": len(gradients),
            "forward_and_loss_seconds": forward_done - started,
            "backward_and_checks_seconds": backward_done - forward_done,
            "optimizer_seconds": step_done - backward_done,
            "step_seconds": step_done - started,
            "loss_components": {key: float(value.detach()) for key, value in losses.items()},
        }
        report["steps"].append(record)
        print(
            json.dumps({key: record[key] for key in ("step", "loss", "step_seconds")}), flush=True
        )
        del outputs, losses, loss, gradients
    report["peak_allocated_bytes"] = torch.cuda.max_memory_allocated()
    report["peak_reserved_bytes"] = torch.cuda.max_memory_reserved()
    model.eval()
    criterion.eval()
    optimizer.zero_grad(set_to_none=True)
    torch.cuda.synchronize()
    started = time.perf_counter()
    with torch.no_grad():
        outputs = model(images, calibration, targets, image_sizes)
        require_finite(outputs)
        report["eval_shapes"] = {
            key: list(value.shape)
            for key, value in outputs.items()
            if isinstance(value, torch.Tensor)
        }
        report["native_decode"] = decode_native(outputs, calibration, image_sizes)
    torch.cuda.synchronize()
    report["eval_and_decode_seconds"] = time.perf_counter() - started
    report["status"] = "PASS"
    report["portable_functional_gate"] = "PASS_SYNTHETIC_ONLY"
    report["limitations"] = [
        "No eAP training or AP evidence",
        "No velocity head",
        "No compiled external CUDA operator parity",
        "Random initialization, no useful detector accuracy claim",
        "CUDA grid_sample backward may be nondeterministic",
    ]
    if args.checkpoint:
        args.checkpoint.parent.mkdir(parents=True, exist_ok=True)
        torch.save(
            {
                "model": model.state_dict(),
                "config": config,
                "variant": VARIANT,
                "seed": args.seed,
                "scope": "synthetic_smoke_only",
            },
            args.checkpoint,
        )
        report["checkpoint_sha256"] = sha256(args.checkpoint)


def main() -> int:
    """CLI entry point writing a failure receipt even if a model check raises."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--source-root", type=Path, default=ROOT / "output/detector_sources/MonoDGP"
    )
    parser.add_argument(
        "--portable-root", type=Path, default=ROOT / "output/detector_sources/MonoDGP-portable"
    )
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--checkpoint", type=Path)
    parser.add_argument("--height", type=int, default=384)
    parser.add_argument("--width", type=int, default=1280)
    parser.add_argument("--group-num", type=int, default=11)
    parser.add_argument("--steps", type=int, default=2)
    parser.add_argument("--seed", type=int, default=7)
    args = parser.parse_args()
    report: dict[str, Any] = {"status": "FAIL"}
    try:
        if args.steps < 1 or args.group_num < 1 or args.height % 64 or args.width % 64:
            raise ValueError("Use positive steps/groups and image dimensions divisible by 64.")
        run(args, report)
        returncode = 0
    except Exception as exc:
        report.update(error=f"{type(exc).__name__}: {exc}", traceback=traceback.format_exc())
        traceback.print_exc()
        returncode = 2
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    return returncode


if __name__ == "__main__":
    raise SystemExit(main())
