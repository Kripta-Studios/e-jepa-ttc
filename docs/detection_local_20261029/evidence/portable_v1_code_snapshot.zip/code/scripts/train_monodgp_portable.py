"""Bounded real-RGB experiments for the explicitly declared portable MonoDGP variant."""

# ruff: noqa: E402 -- allow direct script execution from an uninstalled worktree.

from __future__ import annotations

import argparse
import json
import random
import statistics
import subprocess
import sys
import time
import traceback
from collections import OrderedDict
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / "src"), str(ROOT / "scripts")]

import numpy as np
import torch
from smoke_monodgp_portable import VARIANT, build_detector, prepare_source, require_finite, sha256

from e_jepa_ttc.detection.development_metrics import evaluate_detections
from e_jepa_ttc.detection.eap_rgb_data import EAPRGBDataset
from e_jepa_ttc.detection.monodgp_eap_adapter import decode_eap, prepare_sample


def write_json(path: Path, value: Any) -> None:
    """Write finite machine-readable experiment artifacts."""
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n", encoding="utf-8")


class PreparedCache:
    """Keep a bounded set of resized CPU inputs, not the entire raw image dataset."""

    def __init__(self, dataset: EAPRGBDataset, width: int, height: int, capacity: int = 32) -> None:
        self.dataset, self.width, self.height, self.capacity = dataset, width, height, capacity
        self.cache: OrderedDict[int, tuple] = OrderedDict()
        self.receipts: dict[str, dict] = {}

    def get(self, index: int) -> tuple:
        """Return prepared input, extrinsic, and token with a stable data receipt."""
        if index not in self.cache:
            sample = self.dataset[index]
            prepared = prepare_sample(sample, width=self.width, height=self.height)
            self.cache[index] = prepared, sample.event_from_ego, sample.sample_token
            self.receipts[sample.sample_token] = {
                **prepared.report,
                "rgb_member_sha256": sample.member_sha256,
            }
            if len(self.cache) > self.capacity:
                self.cache.popitem(last=False)
        self.cache.move_to_end(index)
        return self.cache[index]


def inputs_on_gpu(prepared: Any) -> tuple:
    """Transfer a complete image and supervision through separate arguments."""
    return (
        prepared.image.unsqueeze(0).cuda(),
        prepared.calibration.unsqueeze(0).cuda(),
        [{key: value.cuda() for key, value in prepared.target.items()}],
        prepared.image_size.unsqueeze(0).cuda(),
    )


def evaluate(model: Any, criterion: Any, cache: PreparedCache, output: Path) -> dict:
    """Infer with targets=None and compute losses/metrics only after inference."""
    model.eval()
    criterion.eval()
    predictions, truth, counters, losses = {}, {}, {}, []
    started = time.perf_counter()
    with torch.no_grad():
        for index in range(len(cache.dataset)):
            prepared, extrinsic, token = cache.get(index)
            images, calibration, targets, sizes = inputs_on_gpu(prepared)
            outputs = model(images, calibration, None, sizes)
            require_finite(outputs)
            measured = criterion(outputs, targets)
            require_finite(measured, "evaluation_losses")
            losses.append({key: float(value) for key, value in measured.items()})
            predictions[token], counters[token] = decode_eap(
                outputs,
                0,
                prepared.calibration,
                extrinsic,
                prepared.image_size,
            )
            truth[token] = prepared.native_ground_truth
    torch.cuda.synchronize()
    metrics = evaluate_detections(predictions, truth)
    metrics.update(
        {
            "loss_center_mean": statistics.mean(item["loss_center"] for item in losses),
            "loss_center_median": statistics.median(item["loss_center"] for item in losses),
            "loss_depth_mean": statistics.mean(item["loss_depth"] for item in losses),
            "total_weighted_loss_mean": statistics.mean(
                sum(
                    value * criterion.weight_dict[key]
                    for key, value in item.items()
                    if key in criterion.weight_dict
                )
                for item in losses
            ),
            "inference_and_scoring_seconds": time.perf_counter() - started,
            "model_targets_argument": None,
        }
    )
    write_json(
        output,
        {
            "metrics": metrics,
            "predictions": predictions,
            "ground_truth": truth,
            "decode_counts": counters,
            "losses_by_frame": losses,
            "data_receipts": cache.receipts,
        },
    )
    return metrics


def run(args: argparse.Namespace, report: dict) -> None:
    """Predeclare, train to a fixed budget, reload the checkpoint, and evaluate."""
    if args.output.exists():
        raise FileExistsError(f"Use a new run directory; refusing to overwrite {args.output}")
    args.output.mkdir(parents=True)
    manifest = json.loads(args.manifest.read_text(encoding="utf-8"))
    tokens = manifest[args.role]["sample_tokens"]
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    rng = random.Random(args.seed)
    torch.set_num_threads(4)
    source = prepare_source(args.source_root, args.portable_root, args.output / "upstream.patch")
    model, criterion, config = build_detector(args.portable_root, args.group_num)
    file_paths = [Path(__file__), ROOT / "scripts/smoke_monodgp_portable.py"] + [
        ROOT / "src/e_jepa_ttc/detection" / name
        for name in (
            "portable_attention.py",
            "monodgp_eap_adapter.py",
            "development_metrics.py",
            "eap_rgb_data.py",
        )
    ]
    preregistration = {
        "created_at_utc": datetime.now(UTC).isoformat(),
        "variant": VARIANT,
        "role": args.role,
        "sample_tokens": tokens,
        "seed": args.seed,
        "model_config": config,
        "image_hw": [args.height, args.width],
        "batch_size": 1,
        "learning_rate": args.lr,
        "maximum_steps": args.steps,
        "maximum_training_seconds": args.max_seconds,
        "acceptance": {
            "overfit16_mean_center_loss_ratio_at_most": 0.5,
            "finite_parameters": True,
            "active_class_head_updated": True,
            "criterion_fixed_before_first_real_step": True,
        },
        "manifest_sha256": sha256(args.manifest),
        "source": source,
        "code_sha256": {str(path.relative_to(ROOT)): sha256(path) for path in file_paths},
        "git_commit": subprocess.check_output(
            ["git", "-C", str(ROOT), "rev-parse", "HEAD"], text=True
        ).strip(),
        "torch": torch.__version__,
        "cuda": torch.version.cuda,
        "device": torch.cuda.get_device_name(),
        "initialization": "random_no_pretrained_weights",
        "selection_tokens": manifest["selection"]["sample_tokens"] if args.role == "train" else [],
    }
    write_json(args.output / "preregistration.json", preregistration)
    report.update(
        preregistration_sha256=sha256(args.output / "preregistration.json"),
        source=source,
        role=args.role,
        status="RUNNING",
        training_steps=0,
    )
    train_dataset = EAPRGBDataset(args.data_root, tokens)
    train_cache = PreparedCache(train_dataset, args.width, args.height)
    initial = evaluate(model, criterion, train_cache, args.output / "initial_train.json")
    report["initial_train"] = initial
    print(
        json.dumps(
            {
                "stage": "initial_eval",
                "center_loss": initial["loss_center_mean"],
                "depth_loss": initial["loss_depth_mean"],
            }
        ),
        flush=True,
    )
    optimizer = torch.optim.AdamW(
        (p for p in model.parameters() if p.requires_grad), lr=args.lr, weight_decay=1e-4
    )
    torch.cuda.reset_peak_memory_stats()
    started = time.perf_counter()
    order: list[int] = []
    timings = []
    gradient_norms = []
    active_head_before = model.class_embed[config["dec_layers"] - 1].weight.detach().cpu().clone()
    curve = args.output / "training.jsonl"
    with curve.open("w", encoding="utf-8") as stream:
        for step in range(args.steps):
            if time.perf_counter() - started >= args.max_seconds:
                report["stop_reason"] = "time_budget"
                break
            if not order:
                order = list(range(len(tokens)))
                rng.shuffle(order)
            prepared, _, token = train_cache.get(order.pop())
            images, calibration, targets, sizes = inputs_on_gpu(prepared)
            model.train()
            criterion.train()
            optimizer.zero_grad(set_to_none=True)
            torch.cuda.synchronize()
            tick = time.perf_counter()
            outputs = model(images, calibration, targets, sizes)
            require_finite(outputs)
            loss_values = criterion(outputs, targets)
            require_finite(loss_values, "training_losses")
            loss = sum(
                value * criterion.weight_dict[key]
                for key, value in loss_values.items()
                if key in criterion.weight_dict
            )
            loss.backward()
            norm = torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0, error_if_nonfinite=True)
            optimizer.step()
            torch.cuda.synchronize()
            duration = time.perf_counter() - tick
            timings.append(duration)
            gradient_norms.append(float(norm))
            record = {
                "step": step,
                "sample_token": token,
                "loss": float(loss.detach()),
                "loss_center": float(loss_values["loss_center"].detach()),
                "step_seconds": duration,
                "gradient_norm_before_clip": float(norm),
            }
            stream.write(json.dumps(record, allow_nan=False) + "\n")
            stream.flush()
            report["training_steps"] = step + 1
            if step % 25 == 0 or step == args.steps - 1:
                print(json.dumps(record), flush=True)
            del outputs, loss_values, loss
    report["training_seconds"] = time.perf_counter() - started
    report["step_seconds_median"] = statistics.median(timings)
    report["peak_allocated_bytes"] = torch.cuda.max_memory_allocated()
    report["peak_reserved_bytes"] = torch.cuda.max_memory_reserved()
    report["active_head_updated"] = not torch.equal(
        active_head_before, model.class_embed[config["dec_layers"] - 1].weight.detach().cpu()
    )
    report["all_parameters_finite"] = all(
        torch.isfinite(p).all().item() for p in model.parameters()
    )
    checkpoint = args.output / "checkpoint.pt"
    torch.save(
        {
            "model": model.state_dict(),
            "optimizer": optimizer.state_dict(),
            "config": config,
            "variant": VARIANT,
            "seed": args.seed,
            "steps": report["training_steps"],
            "preregistration_sha256": report["preregistration_sha256"],
        },
        checkpoint,
    )
    report["checkpoint_sha256"] = sha256(checkpoint)
    del model, optimizer
    torch.cuda.empty_cache()
    model, criterion, _ = build_detector(args.portable_root, args.group_num)
    restored = torch.load(checkpoint, map_location="cpu", weights_only=True)
    model.load_state_dict(restored["model"], strict=True)
    del restored
    report["checkpoint_reload"] = "PASS_STRICT"
    final = evaluate(model, criterion, train_cache, args.output / "final_train.json")
    report["final_train"] = final
    ratio = final["loss_center_mean"] / initial["loss_center_mean"]
    report["mean_center_loss_ratio"] = ratio
    report["overfit_acceptance"] = (
        "PASS"
        if (
            args.role == "overfit16"
            and ratio <= 0.5
            and report["all_parameters_finite"]
            and report["active_head_updated"]
        )
        else ("FAIL" if args.role == "overfit16" else "NOT_APPLICABLE_PILOT")
    )
    train_dataset.close()
    if args.role == "train":
        with EAPRGBDataset(args.data_root, manifest["selection"]["sample_tokens"]) as selection:
            report["selection"] = evaluate(
                model,
                criterion,
                PreparedCache(selection, args.width, args.height),
                args.output / "selection.json",
            )
    report["status"] = "COMPLETED"
    print(
        json.dumps(
            {
                "status": report["status"],
                "overfit_acceptance": report["overfit_acceptance"],
                "center_loss_ratio": ratio,
                "step_seconds_median": report["step_seconds_median"],
            }
        ),
        flush=True,
    )


def main() -> int:
    """CLI for explicitly budgeted research runs with failure receipts."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-root", type=Path, required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--role", choices=("overfit16", "train"), default="overfit16")
    parser.add_argument("--steps", type=int, default=400)
    parser.add_argument("--max-seconds", type=float, default=600)
    parser.add_argument("--group-num", type=int, default=11)
    parser.add_argument("--width", type=int, default=640)
    parser.add_argument("--height", type=int, default=384)
    parser.add_argument("--lr", type=float, default=2e-4)
    parser.add_argument("--seed", type=int, default=7)
    parser.add_argument(
        "--source-root", type=Path, default=ROOT / "output/detector_sources/MonoDGP"
    )
    parser.add_argument(
        "--portable-root", type=Path, default=ROOT / "output/detector_sources/MonoDGP-portable"
    )
    args = parser.parse_args()
    if min(args.steps, args.max_seconds, args.group_num, args.lr) <= 0:
        parser.error("Steps, time budget, group count, and learning rate must be positive.")
    if args.output.exists():
        parser.error("Run output already exists; choose a new experiment directory.")
    report: dict[str, Any] = {"status": "FAILED"}
    code = 0
    try:
        run(args, report)
    except Exception as exc:
        report.update(
            status="FAILED", error=f"{type(exc).__name__}: {exc}", traceback=traceback.format_exc()
        )
        traceback.print_exc()
        code = 2
    write_json(args.output / "report.json", report)
    return code


if __name__ == "__main__":
    raise SystemExit(main())
