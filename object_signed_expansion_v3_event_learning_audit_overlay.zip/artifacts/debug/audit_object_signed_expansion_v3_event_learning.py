#!/usr/bin/env python
"""Audit whether Object-Signed-Expansion v3 learns from event-camera data.

Designed to run on CPU while a separate CUDA training job is active. It does
not train the TTC model, change checkpoints, or modify cache shards.

The audit measures:
1. event-cache signal and endpoint diversity;
2. precontext availability;
3. output sensitivity to events versus box motion;
4. raw ordered-score and geometry-score branch magnitudes;
5. input and parameter gradient allocation;
6. frozen linear probes using event embeddings only versus motion only.

Run from the repository root.
"""

from __future__ import annotations

import argparse
import json
import math
import sys
from dataclasses import fields
from pathlib import Path
from typing import Any, Iterable

import numpy as np
import pandas as pd
import torch

ROOT = Path.cwd().resolve()
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "src"))

from e_jepa_ttc.data.object_signed_expansion import (  # noqa: E402
    GarlTTCObjectSignedExpansionDataset,
    ObjectSignedExpansionBatch,
    collate_object_signed_expansion,
)
from e_jepa_ttc.models.object_signed_expansion import (  # noqa: E402
    ObjectCentricSignedExpansionTTC,
    ObjectSignedExpansionConfig,
)
from e_jepa_ttc.training.object_signed_expansion import (  # noqa: E402
    ObjectSignedExpansionLossConfig,
    targets_from_batch,
)


def filtered_dataclass(cls: type[Any], value: dict[str, Any]) -> Any:
    allowed = {item.name for item in fields(cls)}
    return cls(**{key: item for key, item in value.items() if key in allowed})


def json_safe(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, bool)):
        return value
    if isinstance(value, float):
        return value if math.isfinite(value) else None
    if isinstance(value, np.generic):
        return json_safe(value.item())
    if isinstance(value, np.ndarray):
        return [json_safe(item) for item in value.tolist()]
    if isinstance(value, torch.Tensor):
        return json_safe(value.detach().cpu().numpy())
    if isinstance(value, dict):
        return {str(key): json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_safe(item) for item in value]
    return str(value)


def close_dataset(dataset: Any) -> None:
    close_fn = getattr(dataset, "close", None)
    if callable(close_fn):
        close_fn()
        return
    inner = getattr(dataset, "_dataset", None)
    inner_close = getattr(inner, "close", None)
    if callable(inner_close):
        inner_close()


def iter_batches(
    dataset: GarlTTCObjectSignedExpansionDataset,
    *,
    count: int,
    batch_size: int,
    event_field: str,
) -> Iterable[ObjectSignedExpansionBatch]:
    stop = min(len(dataset), count)
    for start in range(0, stop, batch_size):
        records = [dataset[index] for index in range(start, min(start + batch_size, stop))]
        yield collate_object_signed_expansion(records, event_field=event_field)


def pearson(target: np.ndarray, prediction: np.ndarray) -> float | None:
    target = np.asarray(target, dtype=np.float64)
    prediction = np.asarray(prediction, dtype=np.float64)
    if target.size < 2 or target.std() < 1.0e-12 or prediction.std() < 1.0e-12:
        return None
    return float(np.corrcoef(target, prediction)[0, 1])


def balanced_sign(target: np.ndarray, prediction: np.ndarray) -> dict[str, float]:
    target_negative = np.asarray(target) < 0.0
    prediction_negative = np.asarray(prediction) < 0.0
    positive = ~target_negative
    negative = target_negative
    positive_accuracy = (
        float(np.mean(~prediction_negative[positive])) if positive.any() else 0.0
    )
    negative_accuracy = (
        float(np.mean(prediction_negative[negative])) if negative.any() else 0.0
    )
    return {
        "positive_accuracy": positive_accuracy,
        "negative_accuracy": negative_accuracy,
        "balanced_accuracy": 0.5 * (positive_accuracy + negative_accuracy),
    }


def metrics(target: np.ndarray, prediction: np.ndarray) -> dict[str, Any]:
    target = np.asarray(target, dtype=np.float64)
    prediction = np.asarray(prediction, dtype=np.float64)
    result = {
        "count": int(target.size),
        "pearson": pearson(target, prediction),
        "mae": float(np.mean(np.abs(target - prediction))),
        "prediction_std": float(prediction.std()),
        "target_std": float(target.std()),
    }
    result.update(balanced_sign(target, prediction))
    return result


def load_model(
    run_dir: Path,
    device: torch.device,
) -> tuple[
    ObjectCentricSignedExpansionTTC,
    ObjectSignedExpansionLossConfig,
    str,
]:
    checkpoint = torch.load(
        run_dir / "best.pt",
        map_location="cpu",
        weights_only=False,
    )
    if checkpoint.get("artifact_type") != "e_jepa_object_signed_expansion_checkpoint_v3":
        raise ValueError(f"Unexpected checkpoint artifact in {run_dir}")
    model_config = filtered_dataclass(
        ObjectSignedExpansionConfig,
        dict(checkpoint["model_config"]),
    )
    loss_config = filtered_dataclass(
        ObjectSignedExpansionLossConfig,
        dict(checkpoint["loss_config"]),
    )
    train_config = dict(checkpoint["train_config"])
    event_field = str(train_config.get("event_field", "jepa_event_roi"))
    model = ObjectCentricSignedExpansionTTC(model_config)
    model.load_state_dict(checkpoint["model_state_dict"], strict=True)
    model.to(device)
    model.eval()
    return model, loss_config, event_field


def event_cache_statistics(
    dataset: GarlTTCObjectSignedExpansionDataset,
    *,
    count: int,
    event_field: str,
) -> dict[str, Any]:
    channel_sum = None
    channel_sq_sum = None
    channel_nonzero = None
    total_pixels = 0
    endpoint_l1: list[float] = []
    endpoint_cosine: list[float] = []
    identical: list[bool] = []
    activity_delta: list[float] = []
    target_expansion: list[float] = []
    context_valid: list[bool] = []
    motion_rows: list[np.ndarray] = []

    stop = min(len(dataset), count)
    for index in range(stop):
        record = dataset[index]
        events = torch.as_tensor(record[event_field], dtype=torch.float32)
        flat = events.permute(1, 0, 2, 3).reshape(events.shape[1], -1)
        current_sum = flat.sum(dim=1).double()
        current_sq = flat.square().sum(dim=1).double()
        current_nonzero = (flat != 0).sum(dim=1).double()
        channel_sum = current_sum if channel_sum is None else channel_sum + current_sum
        channel_sq_sum = current_sq if channel_sq_sum is None else channel_sq_sum + current_sq
        channel_nonzero = (
            current_nonzero if channel_nonzero is None
            else channel_nonzero + current_nonzero
        )
        total_pixels += int(flat.shape[1])

        first = events[0].reshape(-1)
        second = events[1].reshape(-1)
        endpoint_l1.append(float((second - first).abs().mean()))
        endpoint_cosine.append(
            float(
                torch.nn.functional.cosine_similarity(
                    first.unsqueeze(0),
                    second.unsqueeze(0),
                    dim=1,
                    eps=1.0e-8,
                )[0]
            )
        )
        identical.append(bool(torch.equal(events[0], events[1])))
        activity_delta.append(
            float(events[1].abs().mean() - events[0].abs().mean())
        )
        dt = float(record["garl_delta_t_s"])
        ttc = float(record["ttc_s"])
        target_expansion.append(dt / ttc)
        context_valid.append(bool(record["precontext_motion_valid"]))
        motion_rows.append(
            np.asarray(record["observable_motion"], dtype=np.float64)
        )

    assert channel_sum is not None
    assert channel_sq_sum is not None
    assert channel_nonzero is not None
    mean = channel_sum / total_pixels
    variance = channel_sq_sum / total_pixels - mean.square()
    std = variance.clamp_min(0.0).sqrt()

    motion = np.stack(motion_rows)
    target = np.asarray(target_expansion)
    motion_correlations = []
    for index in range(motion.shape[1]):
        motion_correlations.append(pearson(target, motion[:, index]))

    return {
        "sample_count": stop,
        "precontext_valid_fraction": float(np.mean(context_valid)),
        "identical_endpoint_fraction": float(np.mean(identical)),
        "endpoint_mean_abs_difference": float(np.mean(endpoint_l1)),
        "endpoint_cosine_mean": float(np.mean(endpoint_cosine)),
        "endpoint_cosine_std": float(np.std(endpoint_cosine)),
        "event_activity_delta_target_pearson": pearson(
            target, np.asarray(activity_delta)
        ),
        "per_channel_mean": mean.numpy(),
        "per_channel_std": std.numpy(),
        "per_channel_nonzero_fraction": (
            channel_nonzero / total_pixels
        ).numpy(),
        "motion_feature_target_pearson": motion_correlations,
    }


class BranchCapture:
    def __init__(self, model: ObjectCentricSignedExpansionTTC) -> None:
        self.ordered: list[torch.Tensor] = []
        self.geometry: list[torch.Tensor] = []
        self.handles = [
            model.ordered_score.register_forward_hook(self._ordered_hook),
            model.geometry_residual.register_forward_hook(self._geometry_hook),
        ]

    def _ordered_hook(self, _module: Any, _inputs: Any, output: torch.Tensor) -> None:
        self.ordered.append(output.detach().reshape(-1).cpu())

    def _geometry_hook(self, _module: Any, _inputs: Any, output: torch.Tensor) -> None:
        self.geometry.append(output.detach().reshape(-1).cpu())

    def reset(self) -> None:
        self.ordered.clear()
        self.geometry.clear()

    def close(self) -> None:
        for handle in self.handles:
            handle.remove()


@torch.no_grad()
def modality_and_branch_audit(
    model: ObjectCentricSignedExpansionTTC,
    dataset: GarlTTCObjectSignedExpansionDataset,
    *,
    count: int,
    batch_size: int,
    event_field: str,
    device: torch.device,
) -> dict[str, Any]:
    target_values: list[np.ndarray] = []
    mode_values: dict[str, list[np.ndarray]] = {
        "full": [],
        "zero_events": [],
        "shuffled_events": [],
        "reversed_events": [],
        "zero_motion": [],
    }
    event_scores: dict[str, list[np.ndarray]] = {
        "full": [],
        "shuffled_events": [],
        "zero_events": [],
    }
    geometry_scores: list[np.ndarray] = []

    capture = BranchCapture(model)
    try:
        for raw_batch in iter_batches(
            dataset,
            count=count,
            batch_size=batch_size,
            event_field=event_field,
        ):
            batch = raw_batch.to(device, non_blocking=False)
            target = (batch.delta_t_s / batch.target_ttc_s).cpu().numpy()
            target_values.append(target)
            original = batch.model_inputs()

            variants = {
                "full": original,
                "zero_events": {
                    **original,
                    "events": torch.zeros_like(batch.events),
                },
                "shuffled_events": {
                    **original,
                    "events": torch.roll(batch.events, shifts=1, dims=0)
                    if batch.events.shape[0] > 1
                    else torch.flip(batch.events, dims=(1,)),
                },
                "reversed_events": {
                    **original,
                    "events": torch.flip(batch.events, dims=(1,)),
                },
                "zero_motion": {
                    **original,
                    "observable_motion": torch.zeros_like(
                        batch.observable_motion
                    ),
                    "jepa_context_motion": torch.zeros_like(
                        batch.jepa_context_motion
                    ),
                    "precontext_motion_valid": torch.zeros_like(
                        batch.precontext_motion_valid
                    ),
                },
            }

            for mode, inputs in variants.items():
                capture.reset()
                output = model(**inputs)
                mode_values[mode].append(
                    output.signed_expansion.detach().cpu().numpy()
                )
                if mode in event_scores:
                    if len(capture.ordered) != 2:
                        raise RuntimeError(
                            "Expected exactly two ordered-score calls"
                        )
                    score = 0.5 * (
                        capture.ordered[0].numpy()
                        - capture.ordered[1].numpy()
                    )
                    event_scores[mode].append(score)
                if mode == "full":
                    if len(capture.geometry) != 1:
                        raise RuntimeError(
                            "Expected exactly one geometry-score call"
                        )
                    geometry_scores.append(capture.geometry[0].numpy())
    finally:
        capture.close()

    target = np.concatenate(target_values)
    predictions = {
        key: np.concatenate(value)
        for key, value in mode_values.items()
    }
    full = predictions["full"]
    result: dict[str, Any] = {
        "prediction_metrics": {
            key: metrics(target, value)
            for key, value in predictions.items()
        },
        "mean_abs_prediction_change_from_full": {
            key: float(np.mean(np.abs(value - full)))
            for key, value in predictions.items()
            if key != "full"
        },
    }
    geometry = np.concatenate(geometry_scores)
    result["geometry_score"] = {
        "mean_abs": float(np.mean(np.abs(geometry))),
        "std": float(np.std(geometry)),
        "target_pearson": pearson(target, geometry),
    }
    result["ordered_score"] = {}
    full_score = np.concatenate(event_scores["full"])
    for key, values in event_scores.items():
        score = np.concatenate(values)
        result["ordered_score"][key] = {
            "mean_abs": float(np.mean(np.abs(score))),
            "std": float(np.std(score)),
            "target_pearson": pearson(target, score),
            "mean_abs_change_from_full": (
                0.0
                if key == "full"
                else float(np.mean(np.abs(score - full_score)))
            ),
        }
    return result


def gradient_audit(
    model: ObjectCentricSignedExpansionTTC,
    dataset: GarlTTCObjectSignedExpansionDataset,
    *,
    count: int,
    event_field: str,
    device: torch.device,
    loss_config: ObjectSignedExpansionLossConfig,
) -> dict[str, Any]:
    records = [
        dataset[index]
        for index in range(min(len(dataset), count))
    ]
    batch = collate_object_signed_expansion(
        records,
        event_field=event_field,
    ).to(device, non_blocking=False)

    events = batch.events.detach().clone().requires_grad_(True)
    motion = batch.observable_motion.detach().clone().requires_grad_(True)
    context = batch.jepa_context_motion.detach().clone().requires_grad_(True)
    output = model(
        events=events,
        delta_t_s=batch.delta_t_s,
        observable_motion=motion,
        jepa_context_motion=context,
        precontext_motion_valid=batch.precontext_motion_valid,
    )
    grad_events, grad_motion, grad_context = torch.autograd.grad(
        outputs=output.signed_expansion,
        inputs=(events, motion, context),
        grad_outputs=torch.ones_like(output.signed_expansion)
        / output.signed_expansion.numel(),
        retain_graph=False,
        create_graph=False,
    )

    input_sensitivity = {
        "events_mean_abs_gradient": float(grad_events.abs().mean().cpu()),
        "motion_mean_abs_gradient": float(grad_motion.abs().mean().cpu()),
        "context_mean_abs_gradient": float(grad_context.abs().mean().cpu()),
        "events_scaled_sensitivity": float(
            (grad_events.abs() * events.detach().abs()).mean().cpu()
        ),
        "motion_scaled_sensitivity": float(
            (grad_motion.abs() * motion.detach().abs()).mean().cpu()
        ),
        "context_scaled_sensitivity": float(
            (grad_context.abs() * context.detach().abs()).mean().cpu()
        ),
    }

    model.zero_grad(set_to_none=True)
    output = model(**batch.model_inputs())
    targets = targets_from_batch(batch, loss_config)
    supervised = torch.nn.functional.smooth_l1_loss(
        output.signed_expansion,
        targets.signed_expansion,
        beta=loss_config.expansion_beta,
    )
    supervised.backward()

    groups = {
        "encoder": model.encoder,
        "endpoint_adapter": model.endpoint_adapter,
        "activity_fusion": model.activity_fusion,
        "motion_encoder": model.motion_encoder,
        "latent_predictor": model.latent_predictor,
        "ordered_projector": model.ordered_projector,
        "ordered_score": model.ordered_score,
        "geometry_residual": model.geometry_residual,
        "activity_head": model.activity_head,
    }
    parameter_gradients = {}
    for name, module in groups.items():
        squares = []
        count_parameters = 0
        count_with_grad = 0
        for parameter in module.parameters():
            if not parameter.requires_grad:
                continue
            count_parameters += parameter.numel()
            if parameter.grad is not None:
                count_with_grad += parameter.numel()
                squares.append(parameter.grad.detach().float().square().sum())
        norm = (
            float(torch.stack(squares).sum().sqrt().cpu())
            if squares
            else 0.0
        )
        parameter_gradients[name] = {
            "l2_gradient_norm": norm,
            "trainable_parameter_count": count_parameters,
            "parameters_with_gradient": count_with_grad,
        }
    model.zero_grad(set_to_none=True)
    return {
        "input_sensitivity": input_sensitivity,
        "supervised_loss": float(supervised.detach().cpu()),
        "parameter_gradients": parameter_gradients,
    }


@torch.no_grad()
def extract_probe_features(
    model: ObjectCentricSignedExpansionTTC,
    dataset: GarlTTCObjectSignedExpansionDataset,
    *,
    count: int,
    batch_size: int,
    event_field: str,
    device: torch.device,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    event_features: list[np.ndarray] = []
    motion_features: list[np.ndarray] = []
    targets: list[np.ndarray] = []
    for raw_batch in iter_batches(
        dataset,
        count=count,
        batch_size=batch_size,
        event_field=event_field,
    ):
        batch = raw_batch.to(device, non_blocking=False)
        output = model(**batch.model_inputs())
        endpoints = output.endpoint_embeddings
        first = endpoints[:, 0]
        second = endpoints[:, 1]
        event_pair = torch.cat(
            (
                second - first,
                (second - first).abs(),
                first * second,
            ),
            dim=-1,
        )
        motion_pair = torch.cat(
            (
                batch.observable_motion,
                batch.jepa_context_motion
                * batch.precontext_motion_valid.to(
                    batch.observable_motion.dtype
                ).unsqueeze(-1),
                batch.delta_t_s.unsqueeze(-1),
            ),
            dim=-1,
        )
        event_features.append(event_pair.cpu().numpy())
        motion_features.append(motion_pair.cpu().numpy())
        targets.append(
            (batch.delta_t_s / batch.target_ttc_s).cpu().numpy()
        )
    return (
        np.concatenate(event_features),
        np.concatenate(motion_features),
        np.concatenate(targets),
    )


def ridge_probe(
    train_x: np.ndarray,
    train_y: np.ndarray,
    validation_x: np.ndarray,
    validation_y: np.ndarray,
    *,
    alpha: float = 1.0,
) -> dict[str, Any]:
    mean = train_x.mean(axis=0, keepdims=True)
    std = train_x.std(axis=0, keepdims=True)
    std = np.maximum(std, 1.0e-6)
    x_train = (train_x - mean) / std
    x_validation = (validation_x - mean) / std
    x_train = np.concatenate(
        (x_train, np.ones((x_train.shape[0], 1))),
        axis=1,
    )
    x_validation = np.concatenate(
        (x_validation, np.ones((x_validation.shape[0], 1))),
        axis=1,
    )
    regularizer = np.eye(x_train.shape[1], dtype=np.float64) * alpha
    regularizer[-1, -1] = 0.0
    weights = np.linalg.solve(
        x_train.T @ x_train + regularizer,
        x_train.T @ train_y,
    )
    train_prediction = x_train @ weights
    validation_prediction = x_validation @ weights
    return {
        "alpha": alpha,
        "feature_dim": int(train_x.shape[1]),
        "train": metrics(train_y, train_prediction),
        "validation": metrics(validation_y, validation_prediction),
    }


def probe_audit(
    model: ObjectCentricSignedExpansionTTC,
    manifest: Path,
    *,
    train_count: int,
    validation_count: int,
    batch_size: int,
    event_field: str,
    device: torch.device,
) -> dict[str, Any]:
    train_dataset = GarlTTCObjectSignedExpansionDataset(
        str(manifest),
        splits=("train",),
        event_field=event_field,
    )
    validation_dataset = GarlTTCObjectSignedExpansionDataset(
        str(manifest),
        splits=("validation",),
        event_field=event_field,
    )
    try:
        train_event, train_motion, train_y = extract_probe_features(
            model,
            train_dataset,
            count=train_count,
            batch_size=batch_size,
            event_field=event_field,
            device=device,
        )
        validation_event, validation_motion, validation_y = (
            extract_probe_features(
                model,
                validation_dataset,
                count=validation_count,
                batch_size=batch_size,
                event_field=event_field,
                device=device,
            )
        )
    finally:
        close_dataset(train_dataset)
        close_dataset(validation_dataset)

    return {
        "event_embedding_only": ridge_probe(
            train_event,
            train_y,
            validation_event,
            validation_y,
        ),
        "motion_only": ridge_probe(
            train_motion,
            train_y,
            validation_motion,
            validation_y,
        ),
    }


def audit_arm(
    name: str,
    run_dir: Path,
    manifest: Path,
    *,
    device: torch.device,
    sample_count: int,
    probe_train_count: int,
    probe_validation_count: int,
    batch_size: int,
    gradient_samples: int,
) -> dict[str, Any]:
    print(f"\n===== AUDITING {name} =====", flush=True)
    model, loss_config, event_field = load_model(run_dir, device)
    validation_dataset = GarlTTCObjectSignedExpansionDataset(
        str(manifest),
        splits=("validation",),
        event_field=event_field,
    )
    try:
        print("Cache statistics...", flush=True)
        cache_stats = event_cache_statistics(
            validation_dataset,
            count=sample_count,
            event_field=event_field,
        )
        print("Modality and branch sensitivity...", flush=True)
        modality = modality_and_branch_audit(
            model,
            validation_dataset,
            count=sample_count,
            batch_size=batch_size,
            event_field=event_field,
            device=device,
        )
        print("Gradient allocation...", flush=True)
        gradients = gradient_audit(
            model,
            validation_dataset,
            count=gradient_samples,
            event_field=event_field,
            device=device,
            loss_config=loss_config,
        )
    finally:
        close_dataset(validation_dataset)

    print("Frozen event/motion probes...", flush=True)
    probes = probe_audit(
        model,
        manifest,
        train_count=probe_train_count,
        validation_count=probe_validation_count,
        batch_size=batch_size,
        event_field=event_field,
        device=device,
    )
    return {
        "arm": name,
        "run_dir": run_dir.resolve().as_posix(),
        "event_field": event_field,
        "cache_statistics": cache_stats,
        "modality_and_branch": modality,
        "gradients": gradients,
        "linear_probes": probes,
    }


def compact_rows(result: dict[str, Any]) -> list[dict[str, Any]]:
    rows = []
    for arm in result["arms"]:
        modality = arm["modality_and_branch"]
        gradients = arm["gradients"]
        probes = arm["linear_probes"]
        cache = arm["cache_statistics"]
        prediction_metrics = modality["prediction_metrics"]
        rows.append(
            {
                "arm": arm["arm"],
                "precontext_valid_fraction": cache[
                    "precontext_valid_fraction"
                ],
                "endpoint_cosine_mean": cache["endpoint_cosine_mean"],
                "endpoint_mean_abs_difference": cache[
                    "endpoint_mean_abs_difference"
                ],
                "full_expansion_pearson": prediction_metrics["full"][
                    "pearson"
                ],
                "zero_events_expansion_pearson": prediction_metrics[
                    "zero_events"
                ]["pearson"],
                "shuffled_events_expansion_pearson": prediction_metrics[
                    "shuffled_events"
                ]["pearson"],
                "zero_motion_expansion_pearson": prediction_metrics[
                    "zero_motion"
                ]["pearson"],
                "prediction_change_zero_events": modality[
                    "mean_abs_prediction_change_from_full"
                ]["zero_events"],
                "prediction_change_shuffled_events": modality[
                    "mean_abs_prediction_change_from_full"
                ]["shuffled_events"],
                "ordered_score_change_shuffled_events": modality[
                    "ordered_score"
                ]["shuffled_events"]["mean_abs_change_from_full"],
                "ordered_score_change_zero_events": modality[
                    "ordered_score"
                ]["zero_events"]["mean_abs_change_from_full"],
                "ordered_score_mean_abs": modality["ordered_score"]["full"][
                    "mean_abs"
                ],
                "geometry_score_mean_abs": modality["geometry_score"][
                    "mean_abs"
                ],
                "events_scaled_sensitivity": gradients[
                    "input_sensitivity"
                ]["events_scaled_sensitivity"],
                "motion_scaled_sensitivity": gradients[
                    "input_sensitivity"
                ]["motion_scaled_sensitivity"],
                "encoder_gradient_norm": gradients[
                    "parameter_gradients"
                ]["encoder"]["l2_gradient_norm"],
                "motion_encoder_gradient_norm": gradients[
                    "parameter_gradients"
                ]["motion_encoder"]["l2_gradient_norm"],
                "event_probe_validation_pearson": probes[
                    "event_embedding_only"
                ]["validation"]["pearson"],
                "event_probe_validation_balanced_sign": probes[
                    "event_embedding_only"
                ]["validation"]["balanced_accuracy"],
                "motion_probe_validation_pearson": probes["motion_only"][
                    "validation"
                ]["pearson"],
                "motion_probe_validation_balanced_sign": probes[
                    "motion_only"
                ]["validation"]["balanced_accuracy"],
            }
        )
    return rows


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--scratch-dir", type=Path, required=True)
    parser.add_argument("--transfer-dir", type=Path, required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--device", default="cpu")
    parser.add_argument("--sample-count", type=int, default=256)
    parser.add_argument("--probe-train-count", type=int, default=256)
    parser.add_argument("--probe-validation-count", type=int, default=256)
    parser.add_argument("--gradient-samples", type=int, default=4)
    parser.add_argument("--batch-size", type=int, default=4)
    args = parser.parse_args()

    device = torch.device(args.device)
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    result = {
        "artifact_type": "object_signed_expansion_v3_event_learning_audit_v1",
        "manifest": args.manifest.resolve().as_posix(),
        "device": str(device),
        "arms": [
            audit_arm(
                "scratch",
                args.scratch_dir,
                args.manifest.resolve(),
                device=device,
                sample_count=args.sample_count,
                probe_train_count=args.probe_train_count,
                probe_validation_count=args.probe_validation_count,
                batch_size=args.batch_size,
                gradient_samples=args.gradient_samples,
            ),
            audit_arm(
                "level-transfer",
                args.transfer_dir,
                args.manifest.resolve(),
                device=device,
                sample_count=args.sample_count,
                probe_train_count=args.probe_train_count,
                probe_validation_count=args.probe_validation_count,
                batch_size=args.batch_size,
                gradient_samples=args.gradient_samples,
            ),
        ],
    }
    rows = compact_rows(result)
    result["summary"] = rows

    json_path = output_dir / "event_learning_audit.json"
    csv_path = output_dir / "event_learning_summary.csv"
    json_path.write_text(
        json.dumps(json_safe(result), indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    print("\n===== EVENT LEARNING SUMMARY =====")
    print(pd.DataFrame(rows).to_string(index=False))
    print(f"\nWrote {json_path}")
    print(f"Wrote {csv_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
